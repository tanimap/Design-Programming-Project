// Let's make the simplest Pacman ever

// SVG canvas
let width = 600
let height = 600
let black = `rgb(${0}, ${0}, ${0})`

let svg =  document.getElementById("base-svg")
svg.setAttribute("width", width);
svg.setAttribute("height", height);

// Background color for SVG
let rect = document.createElementNS("http://www.w3.org/2000/svg", "rect")
rect.setAttribute("x", 0);
rect.setAttribute("y", 0);
rect.setAttribute("width", width);
rect.setAttribute("height", height);
rect.setAttribute("fill", black);
svg.appendChild(rect)

// All functions will start here

// Pacman head
function pacman(cx, cy, r, colour) {
    let pacman = document.createElementNS("http://www.w3.org/2000/svg", "circle")
    pacman.setAttribute("cx", cx ?? randomInt(width));
    pacman.setAttribute("cy", cy ?? randomInt(height));
    pacman.setAttribute("r", r);
    pacman.setAttribute("fill", colour);
    svg.appendChild(pacman)

}

// Pacman food
function food(cx, cy, r, colour) {
    let food = document.createElementNS("http://www.w3.org/2000/svg", "circle")
    food.setAttribute("cx", cx);
    food.setAttribute("cy", cy);
    food.setAttribute("r", r);
    food.setAttribute("fill", colour);
    svg.appendChild(food)

}

// Pacman trail
function trail(x1, y1, x2, y2, width, colour) {
    let trail = document.createElementNS("http://www.w3.org/2000/svg", "line")
    trail.setAttribute("x1", x1);
    trail.setAttribute("y1", y1);
    trail.setAttribute("x2", x2);
    trail.setAttribute("y2", y2);
    trail.setAttribute("stroke-width", width)
    trail.setAttribute("stroke", colour)
    svg.appendChild(trail)
}

// All functions will start materializing here

// Upper trail travelling through x-axis
trail(0, 50, 35, 50, 10, makeRGB())
trail(170, 50, 230, 50, 10, makeRGB())
trail(270, 50, 330, 50, 10, makeRGB())
trail(370, 50, 430, 50, 10, makeRGB())
trail(470, 50, 530, 50, 10, makeRGB())
trail(570, 50, 630, 50, 10, makeRGB())

// Lower trail travelling through x-axis
trail(0, 150, 35, 150, 10, makeRGB())
trail(170, 150, 230, 150, 10, makeRGB())
trail(270, 150, 330, 150, 10, makeRGB())
trail(370, 150, 430, 150, 10, makeRGB())
trail(470, 150, 530, 150, 10, makeRGB())
trail(570, 150, 630, 150, 10, makeRGB())

// Left trail travelling through y-axis
trail(50, 0, 50, 35, 10, makeRGB())
trail(50, 170, 50, 230, 10, makeRGB())
trail(50, 270, 50, 330, 10, makeRGB())
trail(50, 370, 50, 430, 10, makeRGB())
trail(50, 470, 50, 530, 10, makeRGB())
trail(50, 570, 50, 630, 10, makeRGB())

// Right trail travelling through y-axis
trail(150, 0, 150, 35, 10, makeRGB())
trail(150, 170, 150, 230, 10, makeRGB())
trail(150, 270, 150, 330, 10, makeRGB())
trail(150, 370, 150, 430, 10, makeRGB())
trail(150, 470, 150, 530, 10, makeRGB())
trail(150, 570, 150, 630, 10, makeRGB())

// Food on x-axis
food(0, 100, 15, gray())
food(100, 100, 15, gray())
food(200, 100, 15, gray())
food(300, 100, 15, gray())
food(400, 100, 15, gray())
food(500, 100, 15, gray())
food(600, 100, 15, gray())

// Food on y-axis
food(100, 0, 15, gray())
food(100, 100, 15, gray())
food(100, 200, 15, gray())
food(100, 300, 15, gray())
food(100, 400, 15, gray())
food(100, 500, 15, gray())
food(100, 600, 15, gray())

// Pacman devouring his food with no mouth lol
// cx or cy can be null so that Pacman can move to get to his food
pacman(100, null, 40, yellow())